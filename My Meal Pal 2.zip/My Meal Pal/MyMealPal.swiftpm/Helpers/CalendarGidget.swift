//
//  SwiftUIView.swift
//  
//
//  Created by Ultiimate Dog on 14/02/24.
//

import SwiftUI

struct CalendarGidget: View {
    @State private var date = Date()
    let dWidth: Double
    
    var body: some View {
        Rectangle()
            .fill(Color(UIColor(red: 0.62, green: 0.85, blue: 0.44, alpha: 1.00)).opacity(0.75))
            .frame( width: dWidth*0.47, height:dWidth*0.47)
            .overlay {
                DatePicker("Start Date", selection: $date, displayedComponents: [.date])
                    .transformEffect(.init(scaleX: 0.92, y: 0.9))
                    .colorScheme(.dark)
                    .labelsHidden()
                    .datePickerStyle(.graphical)
                    .padding(.bottom, 20)
                    .padding(.leading, 10)
            }
            // Sets the rounded look of the gidget
            .clipShape(RoundedRectangle(cornerRadius: dWidth * 0.0636, style: .continuous))
            .padding(.all, 5)
    }
}

#Preview {
    CalendarGidget(dWidth: 700)
}
