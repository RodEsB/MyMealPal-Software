//
//  SwiftUIView.swift
//  
//
//  Created by Ultiimate Dog on 14/02/24.
//
import SwiftUI

struct QuickAddButton: View {
    @ObservedObject var modelData: ModelData = .shared
    let dWidth: Double
    let dHeight: Double
    let index: Int
    let col1 = UIColor(red: 0.98, green: 0.97, blue: 0.62, alpha: 1.00)
    var body: some View {
        // Set the visuals of the scan Meal Button
        RoundedRectangle(cornerRadius: dWidth * 0.0636)
            .stroke(Color(col1), lineWidth: 3.5)
            .background(RoundedRectangle(cornerRadius: dWidth * 0.0636).fill(Color(col1).opacity(0.15)))
            .frame( width: dWidth*0.9, height:dHeight*0.05)
            .overlay {
                HStack {
                    Text(modelData.recomendations[index].name)
                    Spacer()
                    Text("| " + String(modelData.recomendations[index].kcal))
                    Text("| " + String(modelData.recomendations[index].protein))
                    Text("| " + String(modelData.recomendations[index].carbs))
                    Text("| " + String(modelData.recomendations[index].fats))
                }
                .bold()
                .foregroundStyle(Color.black)
                .padding(.horizontal)
            }
            .padding(.all, 5)
    }
}

#Preview {
    QuickAddButton(dWidth: 400, dHeight: 700, index: 0)
}
