//
//  SwiftUIView.swift
//  
//
//  Created by Ultiimate Dog on 15/02/24.
//

import SwiftUI

struct ProfileButton: View {
    @State var showProfile = false
    let dWidth: Double
    let dHeight: Double
    
    var body: some View {
        Button {
            self.showProfile.toggle()
        } label: {
            Image(systemName: "person.crop.circle")
                .resizable()
                .scaledToFit()
        }
        .sheet(isPresented: $showProfile) {
            ProfileView()
        }
    }
}

struct SearchButton: View {
    @State var showSearch = false
    @State var searchText = ""
    let dWidth: Double
    let dHeight: Double
    
    var body: some View {
        if showSearch {
            HStack {
                Button {
                    //
                } label: {
                    Image(systemName: "sparkle.magnifyingglass")
                        .resizable()
                        .scaledToFit()
                        .foregroundStyle(Color.red)
                        .frame(height: dHeight*0.035)
                        .fixedSize()
                }
                .padding(.leading, dHeight*0.01)
                TextField("Search Food", text: $searchText)
                    .foregroundStyle(Color.red)
                    .bold()
                Button {
                    withAnimation() {
                        self.showSearch.toggle()
                        searchText = ""
                    }
                } label: {
                    Image(systemName: "xmark")
                        .resizable()
                        .scaledToFit()
                        .foregroundStyle(Color.red)
                        .frame(height: dHeight*0.02)
                }
            }
            .transition(.asymmetric(insertion: .move(edge: .leading), removal: .move(edge: .leading)))
            .padding(.trailing, 10)
            .background(RoundedRectangle(cornerRadius: dHeight*0.022)
                .fill(Color.accentColor.opacity(0.2))
                .frame(height: dHeight*0.044))
        } 
        else {
            Button {
                withAnimation(.bouncy) {
                    self.showSearch.toggle()
                }
            } label: {
                Image(systemName: "sparkle.magnifyingglass")
                    .resizable()
                    .scaledToFit()
            }
            .padding(.trailing, 10)

        }
    }
}

#Preview {
    ProfileButton(dWidth: 300, dHeight: 700)
}
